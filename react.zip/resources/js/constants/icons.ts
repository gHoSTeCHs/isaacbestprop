import logo3 from '../../icons/logo3.svg'

export default {logo3}
