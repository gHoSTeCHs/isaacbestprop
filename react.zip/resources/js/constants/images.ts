import building from '../../images/building.jpeg';
import user2 from '../../images/user2.jpg';
import user1 from '../../images/user1.jpg';
import user3 from '../../images/user3.jpg';
import user4 from '../../images/user4.jpg';
import user5 from '../../images/user5.jpg';
import user6 from '../../images/user6.jpg';
import abstract1 from '../../images/abstract1.png';
import abstract2 from '../../images/abstract2.png';
import client from '../../images/client.png';
import excel from '../../images/excel.png';
import star from '../../images/star.png';
import marketing from '../../images/marketing.png';
import negotiation from '../../images/negotiation.png';
import success from '../../images/success.png';
import valuation from '../../images/valuation.png';
import legal from '../../images/legal.png';
import peace from '../../images/peace.png';
import maintenance from '../../images/maintenance.png';
import tenant from '../../images/tenant.png';
import law from '../../images/law.png';
import guide from '../../images/guide.png';
import digital from '../../images/digital.png';
import document from '../../images/document.png';
import compliance from '../../images/compliance.png';
import arrow from '../../images/arrowup.png';
import email from '../../images/email.png';
import phone from '../../images/phone.png';
import socials from '../../images/socials.png';
import location from '../../images/location.png';
import siteEvaluation from '../../images/evaluate.png';
import compensation from '../../images/compensation.png';
import marketAnalysis from '../../images/marketAnalysis.png';
import dueDiligence from '../../images/dueDiligence.png';
import transactionSupport from '../../images/transactionSupport.png';
import informationSession from '../../images/informationSession.png';
import consultation from '../../images/consultation.png';
import mediation from '../../images/mediation.png';
import workshop from '../../images/workshop.png';
import apartment from '../../images/apartment.jpg';
import buildings from '../../images/building.jpg';
import buildingconstruction from '../../images/buildingconstruction.jpg';
import estate from '../../images/estate.jpg';
import flats from '../../images/flats.jpg';
import hotels from '../../images/hotels.jpg';
import land from '../../images/land.jpg';
import officebuilding from '../../images/officebuilding.jpg';
import penthouse from '../../images/penthouse.jpg';
import resturants from '../../images/resturants.jpg';
import shoppingcenters from '../../images/shoppingcenters.jpg';
import warehouse from '../../images/warehouse.jpg';
import sustainability from '../../images/sustainability.png';
import space_optimization from '../../images/space_optimization.png';
import design from '../../images/design.png';
import architecture from '../../images/architecture.png';

export default {
    building,
    user1,
    user2,
    user3,
    user4,
    user5,
    user6,
    abstract1,
    abstract2,
    client,
    excel,
    star,
    marketing,
    negotiation,
    success,
    valuation,
    legal,
    peace,
    maintenance,
    tenant,
    law,
    guide,
    digital,
    document,
    compliance,
    arrow,
    email,
    phone,
    socials,
    location,
    siteEvaluation,
    compensation,
    marketAnalysis,
    dueDiligence,
    transactionSupport,
    informationSession,
    consultation,
    mediation,
    workshop,
    apartment,
    buildings,
    buildingconstruction,
    estate,
    flats,
    hotels,
    land,
    officebuilding,
    penthouse,
    resturants,
    shoppingcenters,
    warehouse,
    sustainability,
    space_optimization,
    design,
    architecture,
};
