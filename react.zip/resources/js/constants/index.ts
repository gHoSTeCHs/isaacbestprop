import images from '@/constants/images'
import icons from '@/constants/icons'

export {images}
